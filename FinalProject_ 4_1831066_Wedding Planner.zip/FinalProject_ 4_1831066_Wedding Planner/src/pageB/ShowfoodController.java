/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pageB;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author shafa
 */
public class ShowfoodController implements Initializable {
    
    @FXML
    private TableView<User> table;
    @FXML
    private TableColumn<User, String> name;
    @FXML
    private TableColumn<User, Integer> id;
    @FXML
    private TableColumn<User, Double> price;
    
     ObservableList<User> list= FXCollections.observableArrayList(
    
            new User("Chicken Dam Biryani",1,500),
            new User( "Chicken Chaap",2,120),
            new User("Hilsha Fish Curry",3,1000),
            new User("Beef Rejala",4,300),
            new User("Borhani",5,50),
            new User("Hilsha fry",6,400),
            new User("Plain Pulao",7,100),
            new User("Tehari",8,80),
            new User("Egg Vuna",9,50),
            new User("Vegetable",10,20)
            
            );
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        name.setCellValueFactory(new PropertyValueFactory<User, String>("name"));
        id.setCellValueFactory(new PropertyValueFactory<User, Integer>("id"));
        price.setCellValueFactory(new PropertyValueFactory<User, Double>("price"));
        
        table.setItems(list);
        
    }    
    
}
