/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pageB;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import wedding.planner.FXMLDocumentController;

/**
 * FXML Controller class
 *
 * @author shafa
 */
public class Login1Controller implements Initializable {

    @FXML
    private Text welcome;
    @FXML
    private HBox adminDash;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String user= FXMLDocumentController.getVariable();
        
    }    

    @FXML
    private void bookingAction(ActionEvent event) throws IOException  {
        Parent pane=FXMLLoader.load(getClass().getResource("ShowBookings.fxml"));
      
      Scene scene=new Scene (pane);
      
      Stage stage = new Stage ();
      stage.setScene(scene);
      
      stage.show();
        

    }



    @FXML
    private void addVenue(ActionEvent event) throws IOException {
        Parent pane=FXMLLoader.load(getClass().getResource("Add Venue.fxml"));
      
      Scene scene=new Scene (pane);
      
      Stage stage = new Stage ();
      stage.setScene(scene);
      
      stage.show();
        
        
    }

    @FXML
    private void foodItems(ActionEvent event) throws IOException   {
         
  Parent pane=FXMLLoader.load(getClass().getResource("showfood.fxml"));
      
      Scene scene=new Scene (pane);
      
      Stage stage = new Stage ();
      stage.setScene(scene);
      
      stage.show();
    
}

    @FXML
    private void signOut(ActionEvent event) throws IOException {
        Parent pane=FXMLLoader.load(getClass().getResource("FXMLDocument1.fxml"));
      
      Scene scene=new Scene (pane);
      
      Stage stage = new Stage ();
      stage.setScene(scene);
      
      stage.show();
        
    }

    @FXML
    private void userDetails(ActionEvent event) throws IOException {
         Parent pane=FXMLLoader.load(getClass().getResource("viewUsers.fxml"));
      
      Scene scene=new Scene (pane);
      
      Stage stage = new Stage ();
      stage.setScene(scene);
      
      stage.show();

    }
}