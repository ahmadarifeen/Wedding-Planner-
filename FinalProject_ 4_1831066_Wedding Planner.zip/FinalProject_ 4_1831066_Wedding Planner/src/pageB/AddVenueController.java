/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pageB;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author shafa
 */
public class AddVenueController implements Initializable {

    @FXML
    private AnchorPane tableView;
    @FXML
    private TextField addVenue;
    @FXML
    private TextField name;
    @FXML
    private ListView<String> ListOfNames;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addName(MouseEvent event) {
         ListOfNames.getItems().add(name.getText());
    }

    @FXML
    private void removeName(MouseEvent event) {
        int selectedID = ListOfNames.getSelectionModel().getSelectedIndex();
        ListOfNames.getItems().remove(selectedID);
    }
    
}
