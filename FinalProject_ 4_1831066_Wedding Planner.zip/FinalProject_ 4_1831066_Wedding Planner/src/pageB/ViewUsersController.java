/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pageB;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author shafa
 */
public class ViewUsersController implements Initializable {

    @FXML
    private TableView<user2> table;
    @FXML
    private TableColumn<user2, Integer> id;
    @FXML
    private TableColumn<user2, String> name;
    @FXML
    private TableColumn<user2, String> position;
    @FXML
    private TableColumn<user2, Integer> phone;

    /**
     * Initializes the controller class.
     */
    ObservableList<user2> list= FXCollections.observableArrayList(
      new user2(1,"Ahmed Mustakim","Organiser",0123213),
      new user2(2,"Julkar Nien","Caterer",0113214),
      new user2(3,"Rima Akhter","Customer",0113213),
      new user2(4,"Rashiq Abdullah","Organiser",0103513),  
      new user2(5,"Chinmoy Sarker","Customer",0103213)            
);
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        id.setCellValueFactory(new PropertyValueFactory<user2, Integer>("id"));
        name.setCellValueFactory(new PropertyValueFactory<user2, String>("name"));
        position.setCellValueFactory(new PropertyValueFactory<user2, String>("position"));
        phone.setCellValueFactory(new PropertyValueFactory<user2, Integer>("phone"));
        
        table.setItems(list);
    }    

    private void showDetails(ActionEvent event) throws IOException {
          

    }

    private void showDetails(MouseEvent event) throws IOException {
        Parent pane=FXMLLoader.load(getClass().getResource("user1Details.fxml"));
      
      Scene scene=new Scene (pane);
      
      Stage stage = new Stage ();
      stage.setScene(scene);
      
      stage.show();
    }

    

    
}
