/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pageB;

/**
 *
 * @author shafa
 */
public class user2 {
    
    private int id;
    private String name;
    private String position;
    private int phone;

    public user2(int id, String name, String position, int phone) {
        this.id = id;
        this.name = name;
        this.position = position;
        this.phone = phone;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public int getPhone() {
        return phone;
    }
    
    
}
