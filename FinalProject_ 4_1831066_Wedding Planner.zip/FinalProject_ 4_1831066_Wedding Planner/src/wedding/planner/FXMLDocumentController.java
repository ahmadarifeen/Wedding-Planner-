/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wedding.planner;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author shafa
 */
public class FXMLDocumentController implements Initializable {
    
    static ObservableList list=FXCollections.observableArrayList();
    
    String username= "admin";
    String password= "1234";
    
    
    
   
    static String uname="";
    @FXML
    private BorderPane loginscene;
    @FXML
    private TextField user;
    @FXML
    private TextField pass;
    @FXML
    private AnchorPane scene1;
    
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
       public static String getVariable(){
        return uname;
    }
         

    @FXML
    private void signupUser(ActionEvent event) throws IOException  {
    Parent pane=FXMLLoader.load(getClass().getResource("registration.fxml"));
      
      Scene scene=new Scene (pane);
      
      Stage stage = new Stage ();
      stage.setScene(scene);
      
      stage.show();
    }

    @FXML
    private void loginUser(ActionEvent event) throws IOException {
        String name= user.getText();
    String passw = pass.getText();
    if (name.isEmpty()||passw.isEmpty()){
    Alert alert= new Alert(AlertType.ERROR);
    alert.setHeaderText(null);
    alert.setContentText("Fill all required fields");
    
    alert.showAndWait();
    }
    else{
     if(name.equals(username)&&passw.equals(password)){
       FXMLDocumentController.uname=name;
       ((Node)event.getSource()).getScene().getWindow().hide(); 
       loadWindow("/pageB/login1.fxml","Page B");
    } 
     else {
         Alert alert= new Alert(AlertType.ERROR);
    alert.setHeaderText(null);
    alert.setContentText("Sorry! Please enter correct credentials");
    
    alert.showAndWait();
    }
    }
    } 
    
   private void loadWindow(String location,String title) throws IOException{ 
       
       Parent root=FXMLLoader.load(getClass().getResource(location));
       Scene scene = new Scene (root);
       Stage stage=new Stage (StageStyle.DECORATED);
       
       stage.setScene(scene);
       stage.setTitle(title);
       stage.show();
       
       
       
       
    }

}